import { connect } from "react-redux";
import SearchBox from "../components/SearchBox";
import {loadSearch} from "../actions";

function mapStateToProps(state) {
  return {
    searchResults: state.searchResults,
    myMovieList: state.myMovieList
  };
}
function mapDispatchToProps(dispatch) {
  return {
    loadSearch: function (term) {
      dispatch(loadSearch(term));
    }
  };
}

const SearchBoxContainer = connect(mapStateToProps,mapDispatchToProps)(SearchBox);
export default SearchBoxContainer;
